#!/usr/bin/env python3
"""
Email Extraction Script for Cascade Analytics

This script fetches unique email addresses from the UserPageAnalytics API
to be used with the CascadeLinesPerUser.py script.

By default, it fetches data from the last month, but you can customize the date range
using command-line arguments.
"""

import os
import requests
import json
import datetime
import argparse
from dotenv import load_dotenv
from typing import List, Set

# Load environment variables from .env file
load_dotenv()

def get_unique_emails(start_timestamp: str, end_timestamp: str) -> Set[str]:
    """
    Get unique emails from the UserPageAnalytics API.
    
    Args:
        start_timestamp: Start time in ISO format (e.g., "2025-01-01T00:00:00Z")
        end_timestamp: End time in ISO format (e.g., "2025-01-02T00:00:00Z")
    
    Returns:
        Set of unique email addresses
    """
    service_key = os.getenv('SERVICE_KEY')
    if not service_key:
        raise ValueError("SERVICE_KEY not found in environment variables")
    
    url = "https://server.codeium.com/api/v1/UserPageAnalytics"
    
    payload = {
        "service_key": service_key,
        "start_timestamp": start_timestamp,
        "end_timestamp": end_timestamp
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        print(f"Fetching user data from {start_timestamp} to {end_timestamp}...")
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        data = response.json()
        
        # Extract unique emails from the response
        unique_emails = set()
        
        # Based on the API response structure, we know emails are in userTableStats
        if "userTableStats" in data and isinstance(data["userTableStats"], list):
            for user in data["userTableStats"]:
                if "email" in user and user["email"]:
                    unique_emails.add(user["email"])
        else:
            def search_for_emails(obj):
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        if key == "email" and isinstance(value, str):
                            unique_emails.add(value)
                        elif isinstance(value, (dict, list)):
                            search_for_emails(value)
                elif isinstance(obj, list):
                    for item in obj:
                        search_for_emails(item)
            
            search_for_emails(data)
        
        print(f"\nFound {len(unique_emails)} unique email addresses")
        return unique_emails
        
    except requests.exceptions.RequestException as e:
        print(f"Error making request: {e}")
        return set()

def save_emails_to_file(emails: Set[str], filename: str = "unique_emails.json") -> None:
    """
    Save the unique emails to a JSON file.
    
    Args:
        emails: Set of email addresses
        filename: Output filename
    """
    with open(filename, "w") as f:
        json.dump(list(emails), f, indent=2)
    
    print(f"Saved {len(emails)} unique emails to {filename}")

def parse_date(date_str: str) -> datetime.datetime:
    """
    Parse a date string in YYYY-MM-DD format.
    
    Args:
        date_str: Date string in YYYY-MM-DD format
        
    Returns:
        datetime object
    """
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"Invalid date format: {date_str}. Please use YYYY-MM-DD format.")

def get_default_start_date() -> datetime.datetime:
    """
    Get the default start date (1 month ago).
    
    Returns:
        datetime object representing 1 month ago
    """
    now = datetime.datetime.now()
    # Go back 1 month (approximately 30 days)
    return now - datetime.timedelta(days=30)

def main():
    """
    Main function to fetch and save unique emails.
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Extract unique email addresses from Cascade Analytics API')
    parser.add_argument('--start-date', type=str, 
                        help='Start date in YYYY-MM-DD format (default: 1 month ago)')
    parser.add_argument('--end-date', type=str, 
                        help='End date in YYYY-MM-DD format (default: today)')
    parser.add_argument('--output', type=str, default="unique_emails.json",
                        help='Output JSON file name (default: unique_emails.json)')
    args = parser.parse_args()
    
    # Set time range
    now = datetime.datetime.now()
    
    # Process start date
    if args.start_date:
        start_date = parse_date(args.start_date)
    else:
        start_date = get_default_start_date()
    
    # Process end date
    if args.end_date:
        end_date = parse_date(args.end_date)
    else:
        end_date = now
    
    # Convert to ISO format with UTC timezone
    start_timestamp = start_date.strftime("%Y-%m-%dT00:00:00Z")
    end_timestamp = end_date.strftime("%Y-%m-%dT23:59:59Z")
    
    print("Starting unique email extraction...")
    print(f"Date range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
    
    unique_emails = get_unique_emails(start_timestamp, end_timestamp)
    
    if unique_emails:
        save_emails_to_file(unique_emails, args.output)
        
        # Print sample of emails (up to 5)
        sample = list(unique_emails)[:5]
        print("\nSample emails:")
        for email in sample:
            print(f"- {email}")
        
        if len(unique_emails) > 5:
            print(f"... and {len(unique_emails) - 5} more")
    else:
        print("No emails found or an error occurred")

if __name__ == "__main__":
    main()
